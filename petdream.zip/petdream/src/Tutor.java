public class Tutor {
    private Integer id;
    private String nome;
    private String cpf;
    private String endereco;
    private String cidade;
    private String uf;
    private String telefoneFixo;
    private String telefoneCelular;
}
