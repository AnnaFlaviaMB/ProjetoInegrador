public class AnamneseEspecial {

        private String sistemaRespiratorio;
        private String sistemaCardiovascular;
        private String sistemaDigestorio;
        private String sistemaUrinario;
        private String sistemaReprodutor;
        private String sistemaLocomotor;
        private String sistemaNeurologico;
        private String peleEAnexos;
        private String olhos;
}
