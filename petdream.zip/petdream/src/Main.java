
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {

        public static void main(String[] args) {

            List<FichaAtendimento> bancoDeDadosVirtual = new ArrayList<>();

            FichaAtendimento ficha;

            Scanner scanner = new Scanner(System.in);

            while (true) {
                ficha = new FichaAtendimento();
                System.out.println();
                System.out.println("NOVA FICHA DE ATENDIMENTO");
                System.out.print("Insira o RG: ");
                String textoDigitado = scanner.nextLine();

                if (textoDigitado.equals("0")) break;

                ficha.setRg(textoDigitado);
                bancoDeDadosVirtual.add(ficha);

                for(FichaAtendimento fichaDoBanco : bancoDeDadosVirtual) {
                    System.out.println("RG da ficha cadastrada: " + fichaDoBanco.getRg());
                }
            }
            {

            }


            try {
                FileWriter myWriter = new FileWriter("meu_arquivo.txt");
                for(FichaAtendimento fichaDoBanco : bancoDeDadosVirtual) {
                    myWriter.write(fichaDoBanco.getRg() + "\n");
                }
                myWriter.close();
                System.out.println("Arquivado com sucesso.");
            } catch (IOException e) {
                System.out.println("Ocorreu um erro.");
                e.printStackTrace();
            }
        }
}
