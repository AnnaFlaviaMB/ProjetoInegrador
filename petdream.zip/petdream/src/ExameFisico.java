public class ExameFisico {

        private String postura;
        private String nivelDeConsciencia;
        private String escoreCorporal;
        private Float tr;
        private Integer fr;
        private Integer fc;
        private Integer tpc;
        private Integer pulso;
        private String hidratacao;
        private String linfonodosSubmandibular;
        private String linfonodosPreEscapulares;
        private String linfonodosPopliteos;
        private String linfonodosInguinais;
        private String mucosaOcular;
        private String mucosaOral;
        private String mucosaPenianaVulvar;
        private String mucosaAnal;
}
