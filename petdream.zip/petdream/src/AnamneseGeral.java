public class AnamneseGeral {
    private Integer id;
    private String queixaPrincipal;
    private String historicoMedico;
    private String alimentacao;
    private String contactantes;
    private String vacinacao;
    private String vermifugacao;
    private String ambiente;
}
